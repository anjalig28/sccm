<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=192.168.10.238;dbname=db_cisco_production',
    'username' => 'readonly',
    'password' => 'readonly',
    'charset' => 'utf8',
];

