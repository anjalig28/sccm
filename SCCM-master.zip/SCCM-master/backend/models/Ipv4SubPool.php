<?php

namespace backend\models;

use Yii;


class Ipv4SubPool extends \common\models\Ipv4SubPool
{
  
}
